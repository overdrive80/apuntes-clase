

public class Rectangulador {

	/**
	 * Calcula el numero de rectangulos distintos que se pueden
	 * formar con varios elementos. Se considera que el rectangulo
	 * 5x7 y el rectangulo 7x5 son iguales. No se considera rectangulos
	 * a los que tienen lado 1.
	 * 
	 * @param i numero de elementos
	 * @return el numero de rectangulos diferentes que se pueden
	 *         formar con este numero de elementos
	 */
	public static Object rectangulosDiferentes(long i) {
		throw new UnsupportedOperationException("hay que implementar este metodo");
	}

}
